from vb2py.vbfunctions import *
from vb2py.vbdebug import *
import ExcelAPI.XLA_Application as X02

"""--------------------------------------------------------------------"""


def Change_Board_Typ(LeftArduino, NewBrd):
    #--------------------------------------------------------------------
    #  If Disable_Set_Arduino_Typ Then Exit Sub
    X02.MsgBox('Todo: Change_Board_Typ')
    ## VB2PY (CheckDirective) VB directive took path 2 on 0

