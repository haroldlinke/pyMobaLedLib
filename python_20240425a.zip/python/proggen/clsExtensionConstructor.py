from vb2py.vbfunctions import *
from vb2py.vbdebug import *

""" 17.04.23: Hardi"""

TypeName = String()
Texts = clsTexts()
Arguments = Collection()
LEDs = String()
InCnt = String()
OutCnt = String()

def class_initialize():
    Texts = clsTexts()
    Arguments = Collection()

# VB2PY (UntranslatedCode) Option Explicit
