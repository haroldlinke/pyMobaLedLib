from vb2py.vbfunctions import *
from vb2py.vbdebug import *

""" https://www.mrexcel.com/board/threads/event-triggered-when-a-shape-is-moved-shapemove-pseudo-event.1031325/
# VB2PY (CheckDirective) VB directive took path 2 on USE_SHAPE_MOVE_EVENT
 USE_SHAPE_MOVE_EVENT
"""


