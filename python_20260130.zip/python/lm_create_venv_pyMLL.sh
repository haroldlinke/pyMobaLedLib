#!/bin/sh

# this sript creates virtual Python environment for pyMLL

sudo apt install python3-venv python3-pip
python3 -m venv ~/pyMLL-env