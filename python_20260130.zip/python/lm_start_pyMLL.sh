#!/bin/sh

# this sript open a virtual Python environment and starts pyMLL in this environment

source ~/pyMLL-env/bin/activate
python3 Arduino/pyMobaLedLib/python/pyMobaLedLib.py
