"""Wrapper around project converter to convert a project"""

from vb2py import projectconverter


if __name__ == '__main__':
    projectconverter.main()