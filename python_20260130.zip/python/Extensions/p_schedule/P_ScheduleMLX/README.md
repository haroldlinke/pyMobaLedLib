# PeterScheulde MobaLedLib Extension 

The library adds Peters alternativ scheduler to MobaLedLib.

More information see https://wiki.mobaledlib.de.

Questions / suggestions / praise / ...
  mobaledlibl@gmx.de

**Revision History:**

**Ver.: 0.01** 26.03.2024: initial test release
**Ver.: 0.16** 18.10.2024: Erste fertige Version (Beta).
**Ver.: 0.17** 25.10.2024: Fehler, wenn 2 Hausobjekte verwendet wurden.
