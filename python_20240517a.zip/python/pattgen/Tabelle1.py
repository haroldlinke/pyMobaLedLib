from vb2py.vbfunctions import *
from vb2py.vbdebug import *

"""# VB2PY (CheckDirective) VB directive took path 2 on False"""


