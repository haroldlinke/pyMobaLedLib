from vb2py.vbfunctions import *
from vb2py.vbdebug import *


Name = String()
Min = String()
Max = String()
TypeName = String()
Default = String()
Options = String()
Texts = clsTexts()

def class_initialize():
    global Texts
    Texts = clsTexts()
    pass

# VB2PY (UntranslatedCode) Option Explicit
